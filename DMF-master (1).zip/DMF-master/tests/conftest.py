import pytest
from pyspark.sql import SparkSession


@pytest.fixture(scope="session")
def spark_session():
    """Create a PySpark session for testing."""
    spark = (
        SparkSession.builder.appName("DMFTests - Spark App")
        .master("local[2]")
        .getOrCreate()
    )
    yield spark
    spark.stop()
