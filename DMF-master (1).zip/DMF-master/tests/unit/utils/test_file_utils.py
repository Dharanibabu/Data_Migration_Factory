import pytest

from dmf.utils.file_utils import read_ini, read_yaml
from tests.dependencies.unit_test import UnitTestAssist


@pytest.fixture(scope="module")
def unit_test_assist():
    return UnitTestAssist()


def test_read_yaml(unit_test_assist, func="test_read_yaml"):
    expected = unit_test_assist.expected["data.json"]["data"][func][0]
    output = read_yaml(unit_test_assist.input["test_yaml_1.yml"]["path"])
    assert unit_test_assist.assert_json(expected, output)

    expected = unit_test_assist.expected["data.json"]["data"][func][1]
    output = read_yaml(unit_test_assist.input["test_yaml_2.yml"]["path"])
    assert unit_test_assist.assert_json(expected, output)


def test_read_ini(unit_test_assist, func="test_read_ini"):
    expected = unit_test_assist.expected["data.json"]["data"][func][0]
    output = read_ini(unit_test_assist.input["test_ini.ini"]["path"])
    assert unit_test_assist.assert_json(expected, output)
