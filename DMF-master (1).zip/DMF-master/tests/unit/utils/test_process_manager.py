import json
from pathlib import Path

import pytest
from pyspark.sql import SparkSession

from dmf.utils.manager import ConfigManager


class TestProcessManager:
    @pytest.fixture
    def configs_dir(self):
        return {
            "input": Path(__file__).parent.joinpath("input", "test_process_manager"),
            "expected": Path(__file__).parent.joinpath(
                "expected", "test_process_manager"
            ),
        }

    @pytest.fixture
    def migration_job(self):
        return ConfigManager()

    def get_expected_output(self, function_name, expected_files):
        expected_json_path = open(expected_files.joinpath(function_name + ".json"))
        expected_json = json.load(expected_json_path)
        return expected_json["config"], expected_json["rulebook"]

    def test_init_process__success(self, migration_job, configs_dir):
        config_file = configs_dir["input"].joinpath("test_config_file_1.yml")
        rulebook_file = configs_dir["input"].joinpath("test_rulebook_file_1.yml")
        expected_output = self.get_expected_output(
            "test_init_migration__success", configs_dir["expected"]
        )

        migration_job.init_config(config_file, rulebook_file)

        assert migration_job.job_config == expected_output[0]
        assert migration_job.spark_config == expected_output[0]["spark"]
        assert migration_job.source_config == expected_output[0]["source"]
        assert migration_job.destination_config == expected_output[0]["destination"]
        assert migration_job.rule_config == expected_output[1]
        assert isinstance(migration_job.spark_session, SparkSession)
        assert (
            migration_job.spark_session.sparkContext.appName
            == expected_output[0]["spark"]["app_name"]
        )
        migration_job.spark_session.stop()

    def test_init_migration__default_spark(self, migration_job, configs_dir):
        config_file = configs_dir["input"].joinpath("test_config_file_2.yml")
        rulebook_file = configs_dir["input"].joinpath("test_rulebook_file_2.yml")
        expected_output = self.get_expected_output(
            "test_init_migration__default_spark", configs_dir["expected"]
        )

        migration_job.init_config(config_file, rulebook_file)

        assert migration_job.job_config == expected_output[0]
        assert migration_job.spark_config is None
        assert migration_job.source_config == expected_output[0]["source"]
        assert migration_job.destination_config == expected_output[0]["destination"]
        assert migration_job.rule_config == expected_output[1]
        assert isinstance(migration_job.spark_session, SparkSession)
        assert migration_job.spark_session.sparkContext.appName.startswith("SparkApp-")

        migration_job.spark_session.stop()
