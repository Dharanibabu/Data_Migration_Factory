import pytest

from dmf.transformers.transformer_utils import TransformerUtils
from tests.dependencies.unit_test import UnitTestAssist


@pytest.fixture(scope="module")
def unit_test_assist(spark_session):
    return UnitTestAssist(spark=spark_session)


@pytest.fixture(scope="module")
def test_obj(scope="module"):
    return TransformerUtils()


class TestTransformerUtils:
    def test_has_column(self, unit_test_assist, test_obj):
        input = unit_test_assist.input["data.json"]["data"]["test_has_column"][0]
        df = unit_test_assist.create_dataframe_from_json(
            input["data"], input["columns"]
        )

        assert test_obj.has_column(df, "age") == True
        assert test_obj.has_column(df, "some_column") == False
