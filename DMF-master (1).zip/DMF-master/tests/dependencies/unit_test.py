import inspect
import json
import logging
import os
from pathlib import Path

from pyspark.sql import SparkSession

from dmf.utils.manager import ConfigManager
from tests.dependencies.utils import read_ini_file, read_json_file, read_yaml_file

log = logging.getLogger(__name__)


class UnitTestAssist:
    """
    A utility class designed to streamline unit test setup and data management for PySpark testing.

    This utility assumes the following directory structure:
    ├── test_file
    │   └── resources/
    │       ├── expected/
    │       │   ├── data.json
    │       │   └── some_data.csv
    │       └── input/
    │           ├── data.json
    │           └── some_data.ini
    ├── test_file.py

    Args:
        spark (pyspark.sql.SparkSession): The Spark session used for PySpark testing.

    When instantiated, this class loads input and expected data from the specified or derived directory path.

    Attributes:
    TODO: (Need to be update this doc)
        input (dict): A dictionary containing file names as keys, each pointing to a dictionary with the file path and the
            loaded data.
            Example:
            {
                "data.json": {
                    "path": "/path/to/test_dir/resources/input/data.json",
                    "data": {...loaded data from data.json...}
                },
                "some_data.json": {
                    "path": "/path/to/test_dir/resources/input/some_data.json",
                    "data": {...loaded data from some_data.json...}
                },
                ...
            }
        expected (dict): A dictionary containing file names as keys, each pointing to a dictionary with the file path and
            the loaded data.
            Example:
            {
                "data.json": {
                    "path": "/path/to/test_dir/resources/expected/data.json",
                    "data": {...loaded data from data.json...}
                },
                "some_data.json": {
                    "path": "/path/to/test_dir/resources/expected/some_data.json",
                    "data": {...loaded data from some_data.json...}
                },
                ...
            }
    """

    def __init__(self, spark: SparkSession = None):
        """
        Initialize the UnitTestAssist class by automatically loading input and expected data.

        Args:
            spark (pyspark.sql.SparkSession, optional): The Spark session used for PySpark testing.

        This method automatically fetches files from the input and expected directories.
        It constructs self.input and self.expected dictionaries accordingly by finding files in the
        resources directories.
        """
        self.spark = spark
        self.test_file_path = inspect.stack()[1].filename
        self.test_file_name = os.path.basename(self.test_file_path)
        self.test_dir_path = os.path.dirname(self.test_file_path)

        self.input = self.__get_files_in_directory("input")
        self.expected = self.__get_files_in_directory("expected")

    def __get_files_in_directory(self, dir_type: str):
        """
        Fetches files from the specified directory.

        Args:
            dir_type: type pf resources directory [input/expected]

        Returns:
            dict: A dictionary containing file names as keys, each pointing to a dictionary with the file path and the
            loaded data.
        """
        data = {}
        directory_path = os.path.join(
            self.test_dir_path, self.test_file_name.split(".")[0], "resources", dir_type
        )
        for file_name in os.listdir(directory_path):
            file_path = os.path.join(directory_path, file_name)
            if os.path.isfile(file_path):
                file_data = self.__read_test_file(file_path)
                data[file_name] = {"path": file_path, "data": file_data}
        return data

    @staticmethod
    def __read_test_file(file_path: str):
        """
        Function to read the input/expected files based on file format.
        currently supporting json, yml.

        NOTE:
            can be added more types if needed.
        Returns:
        """
        input_type = Path(file_path).suffix[1:]
        if input_type == "json":
            return read_json_file(file_path)
        elif input_type in ["yaml", "yml"]:
            return read_yaml_file(file_path)
        elif input_type == "ini":
            return read_ini_file(file_path)
        else:
            return {}

    @staticmethod
    def __get_test_dir_path():
        """
        This function to find the directory of the path from where the UnitTestAssist class being called.
        Returns: directory of the test file.
        """
        calling_frame = inspect.currentframe().f_back
        calling_filename = calling_frame.f_code.co_filename
        calling_directory = os.path.dirname(calling_filename)
        return calling_directory

    # TODO: Need to update this logic
    def assert_json(self, json1, json2):
        """
        Compare two JSON objects by converting them to sorted strings and checking for equality.

        Args:
        - json1: First JSON object to compare.
        - json2: Second JSON object to compare.

        Returns:
        - bool: True if the JSON objects are equal, False otherwise.
        """
        json1_str = json.dumps(json1, sort_keys=True)
        json2_str = json.dumps(json2, sort_keys=True)
        return json1_str == json2_str

    def create_dataframe_from_json(self, data, columns: list = []):
        """
        Create a Spark DataFrame from JSON data.

        Args:
        - data: JSON data to create the DataFrame.
        - columns (list, optional): List of column names for the DataFrame. Defaults to empty list.

        Returns:
        - DataFrame: Spark DataFrame created from the provided JSON data.

        Raises:
        - ValueError: If the data is empty or if the columns list is empty.
        """
        if not data:
            raise ValueError("No JSON data provided")

        if not columns:
            raise ValueError("Columns list cannot be empty")

        return self.spark.createDataFrame(data, columns)

    def initiate_dmf(self, config_file, rulebook_file=None):
        """
        Initialize the DMF by setting up configuration and rulebook.

        Args:
        - config_file (str): Path to the configuration file.
        - rulebook_file (str, optional): Path to the rulebook file. Defaults to None.

        Returns:
        - ConfigManager: Initialized instance of the ConfigManager for the DMF.

        Description:
        This method initializes the Data Management Framework (DMF) by setting up the configuration
        and, optionally, the rulebook. It uses the provided paths to the configuration and rulebook
        files to configure the DMF and returns an instance of the ConfigManager for further use.

        Example:
        ```
        collector = TestDataCollector()
        manager = collector.initiate_dmf("path/to/config_file.yaml", "path/to/rulebook_file.yaml")
        ```
        """
        manager = ConfigManager()
        manager.init_config(config_file=config_file, rulebook_file=rulebook_file)
        return manager

    def set_manager(self, manager, target):
        """
        Sets attributes from a manager object to a target object.

        Args:
        - manager: Source object containing attributes to be transferred.
        - target: Destination object to which attributes will be transferred.
        """
        for attr_name, attr_value in vars(manager).items():
            setattr(target, attr_name, attr_value)
        return target
