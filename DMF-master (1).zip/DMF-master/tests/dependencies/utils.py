"""
python file has all the helper functions required for TestAssist classes
"""

import json

import jc
import yaml


def read_yaml_file(file_path):
    """
    Read a YAML file and return its contents as a Python object.

    Args:
    file_path (str): The path to the YAML file.

    Returns:
    dict: The contents of the YAML file as a Python dictionary.
    """
    with open(file_path, "r") as file:
        data = yaml.safe_load(file)
    return data


def read_json_file(file_path):
    """
    Read a JSON file and return its contents as a Python object.

    Args:
    file_path (str): The path to the JSON file.

    Returns:
    dict: The contents of the JSON file as a Python dictionary.
    """
    with open(file_path, "r") as file:
        data = json.load(file)
    return data


def read_ini_file(file_path):
    """
    Read a ini file and return its contents as a json.

    Args:
    file_path (str): The path to the ini file.

    Returns:
    dict: The contents of the ini file as a json.
    """
    with open(file_path, "r") as file:
        data = jc.parse("ini", file.read())
    return data
