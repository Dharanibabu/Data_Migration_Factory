#!/bin/bash

# Load Oracle configuration
source oracle_config.env

# Pull the Oracle Docker image
docker pull store/oracle/database-enterprise:19.3.0.0

# Run the Docker container
docker run -d -it --name oracle19c \
-p 1521:1521 -p 5500:5500 \
-e ORACLE_SID="$ORACLE_SID" \
-e ORACLE_PDB="$ORACLE_PDB" \
-e ORACLE_PWD="$ORACLE_PWD" \
store/oracle/database-enterprise:19.3.0.0
